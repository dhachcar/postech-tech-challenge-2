# postech-tech-challenge-2
Repositório com o 2º Tech Challenge da FIAP PosTech

## Sobre
Este repositório contém o notebook utilizado para desenvolvimento do projeto e um backup do modelo + scaler LSTM criado.

## Streamlit
Acesse o [repositório](https://github.com/dhachcar/postech-tech-challenge-2-streamlit) para obter o código Streamlit do projeto.
